import { NextRequest, NextResponse } from "next/server";
import { cookies } from "next/headers";
import { prisma } from "@/lib/prisma";

export async function POST(req: NextRequest) {
  try {
    const cookieStore = await cookies();
    const hasAdminAccess = cookieStore.get("admin_access")?.value === "granted";

    if (!hasAdminAccess) {
      return NextResponse.redirect(new URL("/admin/login", req.url), 303);
    }

    const formData = await req.formData();
    const orderCode = formData.get("orderCode")?.toString();

    if (!orderCode) {
      return NextResponse.redirect(new URL("/admin?error=order-missing", req.url), 303);
    }

    await prisma.orders.update({
      where: {
        order_code: orderCode,
      },
      data: {
        status: "paid",
      },
    });

    return NextResponse.redirect(new URL("/admin?success=order-paid", req.url), 303);
  } catch (error) {
    console.error("Mark paid error:", error);
    return NextResponse.redirect(new URL("/admin?error=order-paid-failed", req.url), 303);
  }
}